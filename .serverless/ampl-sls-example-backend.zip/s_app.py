import serverless_sdk
sdk = serverless_sdk.SDK(
    tenant_id='jrhsls',
    application_name='ampl-sls-example',
    app_uid='NPdQYyqkyNzqR1xhgh',
    tenant_uid='QNpBKVg0bcl58bflzP',
    deployment_uid='911022d0-5d5a-4629-b6db-b6e60ed0f034',
    service_name='ampl-sls-example-backend',
    stage_name='dev',
    plugin_version='3.1.1'
)
handler_wrapper_kwargs = {'function_name': 'ampl-sls-example-backend-dev-app', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('wsgi_handler.handler')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
